'use strict';

const eventClothes = {
  'interview': ['business-casual', 'business'],
  'interview': ['business-casual', 'business'],
  'wedding': ['tuxedo', 'formal', 'semi-formal'],
  'church': ['semi-formal', 'formal', 'conservative'],
  'graduation': ['semi-formal', 'business-casual'],
  'church': ['semi-formal', 'formal', 'conservative'],
  'graduation': ['semi-formal', 'business-casual'],
  'bicep-curl': ['tank-top'],
  'dates': ['chic', 'dressy-casual', 'button up']
}

module.exports = eventClothes;