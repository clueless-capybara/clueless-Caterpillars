'use strict';

module.exports = { };